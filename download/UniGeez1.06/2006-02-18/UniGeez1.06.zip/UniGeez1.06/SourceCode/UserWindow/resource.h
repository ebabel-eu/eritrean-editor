//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UniGeez.rc
//
#define IDM_ABOUT                       100
#define IDI_ICON1                       130
#define ID_CHECK                        1003
#define IDC_MESSAGE                     1004
#define IDC_COMBO_FONTSIZE              1009
#define IDC_COMBO_FONTNAME              1011
#define IDC_EDIT_INSERT_FONT            1015
#define IDC_STATIC6                     1016
#define IDC_STATIC5                     1017
#define IDC_STATIC2                     1018
#define IDC_STATIC1                     1019
#define IDC_STATIC3                     1020
#define IDC_STATIC4                     1021
#define IDC_UPDATES                     1029
#define IDC_GNU                         1032
#define ID_OPTIONS_INFO                 40003
#define IDM_OPTIONS_FONTSIZE            40007
#define IDM_OPTIONS_FONTNAME            40008
#define IDM_FILE_EXIT                   40009
#define ID_MYMENU_GEEZ_ON               40012
#define ID_MYMENU_GEEZ_OFF              40013
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         40015
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
